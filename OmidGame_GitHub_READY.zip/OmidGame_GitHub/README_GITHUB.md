# بازی امید — GitHub Actions

این پروژه برای ساخت خودکار APK با GitHub Actions آماده شده است.

## ساخت APK
1. پروژه را در یک Repository گیت‌هاب قرار دهید.
2. از تب Actions، workflow با نام **Build OmidGame APK** را اجرا کنید.
3. بعد از موفقیت، در صفحه همان اجرای workflow از بخش **Artifacts** فایل **OmidGame-APK** را دانلود کنید.

این workflow از Java 17 و Gradle 8.9 استفاده می‌کند و APK دیباگ را در مسیر `app/build/outputs/apk/debug/app-debug.apk` می‌سازد.
